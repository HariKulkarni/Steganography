<?php
      include "db.php";
      include "header1.php";
     
	 if(isset($_POST['check']))
     {
		$id=$_SESSION['id'];
		$vcode=$_POST['vcode'];
		
		$sql = "select * from msg where id='$id' AND verificationcode='$vcode'";
		
		echo $sql;
		$result=mysqli_query($conn, $sql);
		$rowcount=mysqli_num_rows($result);
		$arr=mysqli_fetch_array($result);
		if ($rowcount > 0)
		{
			
				$file=$arr['file'];
				$_SESSION['file'] = $file;
				echo '<script type="text/javascript">
										alert(" verificationcode is Correct ");
										location="decode.php";
								 </script>';
		}
		else
		{
			echo '<script type="text/javascript">
										alert(" verificationcode is Wrong ");
										location="check2.php";
								 </script>';
		}
	 }
													
?>

    



<div class="container">
        <br>
        <br>

							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>EXTRACT   <span>MESSAGE</span></h4>
										<center>
										
										<form  action="check2.php" method="post" name="sentMessage" id="contactForm" enctype="multipart/form-data">
														<div class="control-group form-group">
															
															<p>	<label class="contact-p1">Enter Verification Code :</label>
																<input type="text" class="form-control" name="vcode" id="name"  required >
																
														   </p>
														</div>
												
														<input type="submit" name="check" value="submit" class="btn btn-primary">	
											</form>			
											            
										
									</center>
																				
                                    </div>
								</div>
</div>
							
<!-- //Modal1 -->

